﻿using System;
using System.Windows.Forms;
using SomeProject.Library.Client;
using SomeProject.Library;
using System.IO;
using System.Collections;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace SomeProject.TcpClient
{
    public partial class ClientMainWindow : Form
    {
        public ClientMainWindow()
        {
            InitializeComponent();
        }

        private void OnMsgBtnClick(object sender, EventArgs e)
        {
            Client client = new Client();
            Result res = client.SendMessageToServer(textBox.Text).Result;
            if(res == Result.OK)
            {
                textBox.Text = "";
                labelRes.Text = "Message was sent succefully!";
            }
            else
            {
                labelRes.Text = "Cannot send the message to the server.";
            }
            timer.Interval = 3500;
            timer.Start();
        }

        private void OnTimerTick(object sender, EventArgs e)
        {
            labelRes.Text = "";
            timer.Stop();
        }
       
        private void sent_file_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                Client client = new Client();

                var res = client.SendFileToServer(fileDialog.FileName);

                if (res.Result == Result.OK)
                    labelRes.Text = "Файл отправлен";
                else
                    labelRes.Text = "Файл не отправлен";

                resBox.Text += res.Message + Environment.NewLine;

                timer.Interval = 3500;
                timer.Start();
            }

        }

        private void textBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void resBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
