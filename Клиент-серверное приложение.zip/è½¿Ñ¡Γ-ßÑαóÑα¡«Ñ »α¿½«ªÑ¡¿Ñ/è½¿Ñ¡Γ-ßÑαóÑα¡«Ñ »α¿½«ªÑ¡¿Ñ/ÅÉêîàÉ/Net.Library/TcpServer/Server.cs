﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SomeProject.Library.Server
{
    public class Server
    {
        TcpListener serverListener;
        static int number_of_file = 0;
        static int count = 0;
        public Server()
        {
            serverListener = new TcpListener(IPAddress.Loopback, 8080);
        }
        /// <summary>
        /// Выключение слушателя
        /// </summary>
        /// <returns></returns>
        public bool TurnOffListener()
        {
            try
            {
                if (serverListener != null)
                    serverListener.Stop();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        /// <summary>
        /// включаем слушатель
        /// </summary>
        /// <returns></returns>
        public async Task TurnOnListener()
        {
            try
            {
                if (serverListener != null)
                    serverListener.Start();
                Console.WriteLine("Сервер включен");
                ThreadPool.SetMaxThreads(10, 10); 
                ThreadPool.SetMinThreads(2, 2);
                while (true)
                    ThreadPool.QueueUserWorkItem(new WaitCallback(Callback), serverListener.AcceptTcpClient());
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        /// <summary>
        /// Обработка полученного соединения
        /// </summary>
        /// <param name="client">клиент</param>
        static void Callback(object client)
        {
            Console.WriteLine("Новое соединение: " + Interlocked.Increment(ref count));
            OperationResult result = ReceiveHeaderFromClient((TcpClient)client).Result;
            if (result.Result == Result.Fail)
                Console.WriteLine(result.Message);
            else
                Console.WriteLine("Новое сообщение от клиента: " + result.Message);
            Interlocked.Decrement(ref count);
        }
        /// <summary>
        /// обработка сообщения
        /// </summary>
        /// <param name="stream">входящий поток</param>
        /// <param name="recievedMessage">начало сообщения проверки файл или не файл</param>
        /// <returns></returns>
        private static string ReceiveMessageFromClient(NetworkStream stream, StringBuilder message)
        {
            try
            {
                byte[] dannie = new byte[256];
                int b = 0;
                do
                {
                    b = stream.Read(dannie, 0, dannie.Length);
                    message.Append(Encoding.UTF8.GetString(dannie, 0, b));
                }
                while (stream.DataAvailable);

                Console.WriteLine(message.ToString());

                return message.ToString();
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }


        /// <summary>
        /// проверяет обрабатываем мы файл или сообщение
        /// </summary>
        /// <param name="client">клиент</param>
        /// <returns></returns>
        public async static Task<OperationResult> ReceiveHeaderFromClient(TcpClient client)
        {
            try
            {
                StringBuilder recievedMessage = new StringBuilder();
                byte[] data = new byte[256];
                string message = "";
                int del = 0;
                using (NetworkStream stream = client.GetStream())
                {
                    int bytes = await stream.ReadAsync(data, 0, data.Length);
                    recievedMessage.Append(Encoding.UTF8.GetString(data, 0, bytes));

                    if ((new Regex(@"@File_Name: (.*)@")).IsMatch(recievedMessage.ToString()))
                    {
                        del = recievedMessage.ToString().IndexOf('@', 1);

                        Console.WriteLine(recievedMessage.ToString().Substring(0, del));
                        var mes = ReceiveFileFromClient(stream, recievedMessage.ToString()
                            .Substring(7, del - 7).Split('.')[0], recievedMessage.ToString().Substring(del + 1));
                        SendMessageToClient(stream, mes.Message);
                    }
                    else
                    {
                        if (stream.DataAvailable)
                            message = ReceiveMessageFromClient(stream, recievedMessage);
                        else
                            message = recievedMessage.ToString();
                        SendMessageToClient(stream, message);
                    }
                }
                client.Close();

                return new OperationResult(Result.OK, message);
            }
            catch (Exception e)
            {
                return new OperationResult(Result.Fail, e.Message);
            }
        }

        /// <summary>
        /// обработка файла
        /// </summary>
        /// <param name="stream">Входящий поток</param>
        /// <param name="ras">Расширение файла</param>
        /// <param name="header">Заголовок файла</param>
        /// <returns></returns>
        private static OperationResult ReceiveFileFromClient(NetworkStream stream, string ras, string header)
        {
            try
            {
                StringBuilder recievedMessage = new StringBuilder().Append(header);

                byte[] data = new byte[4096];



                if (!Directory.Exists(DateTime.Now.ToString("yyyy-mm-dd")))
                {
                    Directory.CreateDirectory(DateTime.Now.ToString("yyyy-mm-dd"));
                }

                int inc = Interlocked.Increment(ref number_of_file);


                using (FileStream fstream = new FileStream(DateTime.Now.ToString("yyyy-mm-dd") + "\\" + inc.ToString() + "." + ras, FileMode.Create))
                {
                    do
                    {
                        int bytes = stream.Read(data, 0, data.Length);
                        fstream.Write(data, 0, bytes);
                    }
                    while (stream.DataAvailable);
                }
                return new OperationResult(Result.OK, DateTime.Now.ToString("yyyy-mm-dd") + "\\" + inc.ToString() + "." + ras);
            }
            catch (Exception e)
            {
                return new OperationResult(Result.Fail, e.Message);
            }
        }

        /// <summary>
        /// отправляем сообщение клиенту единым пакетом
        /// </summary>
        /// <param name="stream">поток</param>
        /// <param name="message">сообщение</param>
        /// <returns></returns>
        private static OperationResult SendMessageToClient(NetworkStream stream, string message)
        {
            try
            {
                byte[] data = Encoding.UTF8.GetBytes(message);

                stream.Write(data, 0, data.Length);
            }

            catch (Exception e)
            {
                return new OperationResult(Result.Fail, e.Message);
            }

            return new OperationResult(Result.OK, "");
        }
    }
}