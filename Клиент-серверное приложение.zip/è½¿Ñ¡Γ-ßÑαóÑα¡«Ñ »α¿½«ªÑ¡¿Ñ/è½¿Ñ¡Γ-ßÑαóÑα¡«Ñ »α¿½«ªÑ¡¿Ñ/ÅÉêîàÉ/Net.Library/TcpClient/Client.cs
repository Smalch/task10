﻿using System;
using System.Text;
using System.Net.Sockets;
using System.IO;

namespace SomeProject.Library.Client
{
    public class Client
    {
        public TcpClient tcpClient;
        /// <summary>
        /// Получение сообщения от сервера
        /// </summary>
        /// <returns></returns>
        public OperationResult ReceiveMessageFromServer()
        {
            try
            {
                tcpClient = new TcpClient("127.0.0.1", 8080);

                StringBuilder recieve = new StringBuilder();

                byte[] d = new byte[256];
                NetworkStream stream = tcpClient.GetStream();

                do
                {
                    int bytes = stream.Read(d, 0, d.Length);
                    recieve.Append(Encoding.UTF8.GetString(d, 0, bytes));
                }
                while (stream.DataAvailable);

                stream.Close();
                tcpClient.Close();

                return new OperationResult(Result.OK, recieve.ToString());
            }
            catch (Exception e)
            {
                return new OperationResult(Result.Fail, e.ToString());
            }
        }
        /// <summary>
        /// Отправка сообщения на сервер
        /// </summary>
        /// <param name="mes">Само сообщение</param>
        /// <returns></returns>
        public OperationResult SendMessageToServer(string mes)
        {
            try
            {
                tcpClient = new TcpClient("127.0.0.1", 8080);


                NetworkStream stream = tcpClient.GetStream();

                byte[] data = System.Text.Encoding.UTF8.GetBytes(mes);

                stream.Write(data, 0, data.Length);

                stream.Close();
                tcpClient.Close();

                return new OperationResult(Result.OK, "") ;
            }
            catch (Exception e)
            {
                return new OperationResult(Result.Fail, e.Message);
            }
        }

        /// <summary>
        ///  Получение сообщение от сервера
        /// </summary>
        /// <param name="stream">поток</param>
        /// <returns></returns>
        public OperationResult ReceiveMessageFromServer(NetworkStream stream)
        {
            try
            {
                StringBuilder recievedMessage = new StringBuilder();
                byte[] d = new byte[256];
                int c=0;
                do
                {
                    c= stream.Read(d, 0, d.Length);
                    recievedMessage.Append(Encoding.UTF8.GetString(d, 0, c));
                }
                while (stream.DataAvailable);
                stream.Close();
                tcpClient.Close();

                return new OperationResult(Result.OK, recievedMessage.ToString());
            }
            catch (Exception e)
            {
                return new OperationResult(Result.Fail, e.ToString());
            }
        }

        /// <summary>
        /// Отправление файла на сервер
        /// </summary>
        /// <param name="fileName">имя файла</param>
        /// <returns></returns>
        public OperationResult SendFileToServer(string fileName)
        {
            try
            {
                using (tcpClient = new TcpClient("127.0.0.1", 8080))
                {
                    using (NetworkStream stream = tcpClient.GetStream())
                    {
                        byte[] fname = Encoding.UTF8.GetBytes("@File_Name: " + fileName.Split('.')[fileName.Split('.').Length - 1] + "@");
                        //Console.WriteLine(fileName.Split('.')[fileName.Split('.').Length - 1]);
                        using (FileStream fstream = new FileStream(fileName, FileMode.Open))
                        {
                            byte[] mas = new byte[4096]; 

                            int kol = 0;

                            do
                            {
                                kol = fstream.Read(mas, 0, mas.Length);

                                stream.Write(mas, 0, kol);



                            } while (kol != 0);
                        }

                        return ReceiveMessageFromServer(stream);
                        //return new OperationResult(Result.OK, "");
                    }
                }
            }
            catch (Exception e)
            {
                return new OperationResult(Result.Fail, e.Message);
            }
        }

    }
}
